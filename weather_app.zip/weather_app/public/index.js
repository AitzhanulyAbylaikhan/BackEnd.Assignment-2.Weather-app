const container = document.querySelector('.container');
const search = document.querySelector('.search-box button');
const weatherBox = document.querySelector('.weather-box');
const weatherDetails = document.querySelector('.weather-details');
const error404 = document.querySelector('.not-found');
const serverBaseUrl = 'http://localhost:3000';

function getWindDirection(degree) {
    // Convert wind direction from degrees to cardinal direction
    const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
    const index = Math.round(degree / 45) % 8;
    return directions[index];
}

function formatTime(timestamp) {
    // Convert Unix timestamp to HH:MM format
    const date = new Date(timestamp * 1000);
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
}

search.addEventListener('click', () => {

    const APIKey = "46599816d0a85d72f74ba74d3d43e49f";
    const city = document.querySelector('.search-box input').value;

    if (city === '')
        return;

    fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${APIKey}`)
        .then(response => response.json())
        .then(json => {


            if (json.cod === '404') {
                container.style.height = '400px';
                weatherBox.style.display = 'none';
                weatherDetails.style.display = 'none';
                error404.style.display = 'block';
                error404.classList.add('fadeIn');
                return;
            }

            error404.style.display = 'none';
            error404.classList.remove('fadeIn');

            const image = document.querySelector('.weather-box img');
            const temperature = document.querySelector('.weather-box .temperature');
            const description = document.querySelector('.weather-box .description');
            const humidity = document.querySelector('.weather-details .humidity span');
            const wind = document.querySelector('.weather-details .wind span');
            const coordinates = document.querySelector('.weather-details .coordinates span');
            const feelsLike = document.querySelector('.weather-details .feels-like span');
            const pressure = document.querySelector('.weather-details .pressure span');
            const countryCode = document.querySelector('.weather-details .country-code span');
            const rainVolume = document.querySelector('.weather-details .rain-volume span');
            const maxMinTemperature = document.querySelector('.max-min-temperature span');
            const windDirection = document.querySelector('.wind-direction span');
            const sunriseSunset = document.querySelector('.sunrise-sunset span');



            switch (json.weather[0].main) {
                case 'Clear':
                    image.src = 'images/clear.png';
                    break;

                case 'Rain':
                    image.src = 'images/rain.png';
                    break;

                case 'Snow':
                    image.src = 'images/snow.png';
                    break;

                case 'Clouds':
                    image.src = 'images/cloud.png';
                    break;

                case 'Mist':
                    image.src = 'images/mist.png';
                    break;

                default:
                    image.src = '';
            }

            temperature.innerHTML = `${parseInt(json.main.temp)}<span>°C</span>`;
            description.innerHTML = `${json.weather[0].description}`;
            humidity.innerHTML = `${json.main.humidity}%`;
            wind.innerHTML = `${parseInt(json.wind.speed)}Km/h`;
            coordinates.innerHTML = `(${json.coord.lat}, ${json.coord.lon})`;
            feelsLike.innerHTML = `${parseInt(json.main.feels_like)}<span>°C</span>`;
            pressure.innerHTML = `${json.main.pressure} hPa`;
            countryCode.innerHTML = `${json.sys.country}`;
            rainVolume.innerHTML = `${json.rain && json.rain['1h'] ? json.rain['1h'] : 0} mm`;
            maxMinTemperature.innerHTML = `${parseInt(json.main.temp_max)}°C / ${parseInt(json.main.temp_min)}°C`;
            windDirection.innerHTML = `${getWindDirection(json.wind.deg)}`;
            sunriseSunset.innerHTML = `${formatTime(json.sys.sunrise)} / ${formatTime(json.sys.sunset)}`;


            weatherBox.style.display = '';
            weatherDetails.style.display = '';
            weatherBox.classList.add('fadeIn');
            weatherDetails.classList.add('fadeIn');
            container.style.height = '590px';

            const mapContainer = document.createElement('div');
            mapContainer.id = 'map';
            mapContainer.style.width = '100%';
            mapContainer.style.height = '300px';
            container.appendChild(mapContainer);

            initializeMap(json.coord.lat, json.coord.lon);

            getNews(city);

            getAirQuality(city);


        });


});

function initializeMap(latitude, longitude) {
    const mapOptions = {
        center: { lat: latitude, lng: longitude },
        zoom: 10,
    };

    const map = new google.maps.Map(document.getElementById('map'), mapOptions);

    const marker = new google.maps.Marker({
        position: { lat: latitude, lng: longitude },
        map: map,
        title: 'City Location'
    });
}



async function getNews(city) {
    const newsApiKey = 'aa86d73e63254943b9d6bbee6867ff20';
    const newsApiUrl = `https://newsapi.org/v2/everything?q=${city}&apiKey=${newsApiKey}`;

    try {
        const response = await fetch(newsApiUrl);
        const newsData = await response.json();
        console.log('News API response:', newsData);

        // Check if there are articles in the response
        if (newsData.articles && newsData.articles.length > 0) {
            // Shuffle the array of articles to get a random order
            const shuffledArticles = shuffle(newsData.articles);

            // Display a random selection of 3 news articles
            const newsContainer = document.getElementById('news-container');
            newsContainer.innerHTML = `<h2>News for ${city}</h2>`;

            for (let i = 0; i < Math.min(3, shuffledArticles.length); i++) {
                const article = shuffledArticles[i];
                newsContainer.innerHTML += `
                    <div>
                        <h3>${article.title}</h3>
                        <p>${article.description}</p>
                        <a href="${article.url}" target="_blank" class="read-more-button">Read more</a>
                    </div>
                `;
            }
        } else {
            console.log('No news found for', city);
        }
    } catch (error) {
        console.error('Error fetching news:', error);
    }
}


function shuffle(array) {
    let currentIndex = array.length, randomIndex;

    // While there remain elements to shuffle...
    while (currentIndex !== 0) {

        // Pick a remaining element...
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex--;

        // And swap it with the current element.
        [array[currentIndex], array[randomIndex]] = [array[randomIndex], array[currentIndex]];
    }

    return array;
}

async function getAirQuality(city) {
    const waqiApiKey = '61e6b682795b56fa49656df4c845a12ddd213c26';
    const waqiApiUrl = `https://api.waqi.info/feed/${city}/?token=${waqiApiKey}`;

    try {
        const response = await fetch(waqiApiUrl);
        const airQualityData = await response.json();
        console.log('WAQI API response:', airQualityData);

        if (airQualityData.status === 'error') {
            console.error('WAQI API error:', airQualityData.data);
            // Handle the error appropriately, e.g., show an error message to the user
        } else {
            // Process the air quality data
            const aqi = airQualityData.data.aqi;
            console.log('Air Quality Index (AQI) for', city, ':', aqi);

            // Display the AQI to the user or further process the information as needed
            const airQualityContainer = document.getElementById('air-quality-container');
            const cityNameElement = document.getElementById('city-name');
            const aqiValueElement = document.getElementById('aqi-value');
            const airQualityIconContainer = document.getElementById('air-quality-icon');

            cityNameElement.textContent = city;
            aqiValueElement.textContent = aqi;

            // Set the air quality icon based on AQI range
            let iconClass = '';
            if (aqi <= 50) {
                // Good
                iconClass = 'fas fa-smile';
            } else if (aqi <= 100) {
                // Moderate
                iconClass = 'fas fa-meh';
            } else {
                // Unhealthy
                iconClass = 'fas fa-frown';
            }

            // Add the icon to the container
            airQualityIconContainer.innerHTML = `<i class="${iconClass}"></i>`;
        }
    } catch (error) {
        console.error('Error fetching WAQI API:', error);
        // Handle the error appropriately, e.g., show an error message to the user
    }
}



